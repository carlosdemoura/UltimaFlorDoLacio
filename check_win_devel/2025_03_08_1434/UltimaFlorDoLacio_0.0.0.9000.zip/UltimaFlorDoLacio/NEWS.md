# UltimaFlorDoLacio 0.1.0

## Changes in version 0.1.0

* Initial CRAN submission (waiting).
